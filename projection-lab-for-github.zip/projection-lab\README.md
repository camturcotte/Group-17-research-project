# Projection Lab

An NFL fantasy football research dashboard for browsing historical Sleeper and ESPN projections and actual results. The `dist` folder contains the static site and its prebuilt data snapshot; `scripts` contains the data-processing and validation scripts used for parts of the dataset.

## Run locally

From this folder, run:

```bash
python -m http.server 8000 --directory dist
```

Open <http://localhost:8000> in a browser. The site must be served over HTTP so it can load the data files; opening `index.html` directly may not work.

## Data and coverage

The included files are a historical snapshot, not a live feed. Coverage varies by source and player; the player directory includes data from 2018–2025 and the first nine weeks of 2026. Career profiles show per-season averages and sample counts. A player's team is the last team recorded in the snapshot. Missing observations are not treated as zero.

Sleeper and ESPN data may have different coverage and scoring details. Consult the explanatory notes in the dashboard when comparing sources, particularly for kickers and defenses. Some processing scripts require raw API caches and other input files that are not included here; run a script with `--help` to see its inputs. Python dependencies for those scripts are listed in `scripts/requirements.txt`.

The deployed private site is managed separately; changes pushed to this GitHub repository do not automatically update that site.
