"""Download ESPN fantasy projections, with raw season cache and coverage reporting."""
import argparse, json, time, os, tempfile
from pathlib import Path
import pandas as pd
import requests
from tqdm import tqdm
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

POS={1:'QB',2:'RB',3:'WR',4:'TE',5:'K',16:'DEF'}
TEAMS={0:'FA',1:'ATL',2:'BUF',3:'CHI',4:'CIN',5:'CLE',6:'DAL',7:'DEN',8:'DET',9:'GB',10:'TEN',11:'IND',12:'KC',13:'LV',14:'LAR',15:'MIA',16:'MIN',17:'NE',18:'NO',19:'NYG',20:'NYJ',21:'PHI',22:'ARI',23:'PIT',24:'LAC',25:'SF',26:'SEA',27:'TB',28:'WAS',29:'CAR',30:'JAX',33:'BAL',34:'HOU'}
STATS={'pass_yd':'3','pass_td':'4','pass_int':'20','rush_yd':'24','rush_td':'25','rec':'53','rec_yd':'42','rec_td':'43','fum_lost':'72','fgm_0_39':'80','fgm_40_49':'77','fgm_50_plus':'74','xpm':'86','def_sack':'99','def_int':'95','def_fum_rec':'96','def_td':'105','def_pts_allowed':'187'}

def normalize(payload,season):
 if isinstance(payload,list):
  if len(payload)!=1: raise ValueError('Invalid legacy response')
  payload=payload[0]
 if not isinstance(payload,dict) or not isinstance(payload.get('players'),list) or not payload['players']: raise ValueError('No player data in response')
 result={};ambiguous=set()
 for e in payload['players']:
  p=e.get('player',e);pos=POS.get(p.get('defaultPositionId'));pid=p.get('id')
  if not pos or pid is None:continue
  for obj in p.get('stats',[]):
   if obj.get('seasonId')!=season:continue
   source=obj.get('statSourceId');week=obj.get('scoringPeriodId');split=obj.get('statSplitTypeId')
   if source not in (0,1) or not ((split==0 and week==0) or (split==1 and isinstance(week,int) and 1<=week<=18)):continue
   key=(season,week,str(pid),source)
   if key in ambiguous:continue
   if key in result:
    old=result[key]['espn_default_pts'];new=obj.get('appliedTotal')
    if (old or 0)>0 and (new or 0)<=0:continue
    if (new or 0)>0 and (old or 0)<=0:pass
    else:
     del result[key];ambiguous.add(key);continue
   st=obj.get('stats') or {};v=lambda k: float(st.get(k) or 0)
   # Use native D/ST points: applying a tier to expected points allowed is invalid.
   if pos=='DEF':
    native=obj.get('appliedTotal');std=half=ppr=float(native) if native is not None else None
   else:
    std=sum(v(k)*coef for k,coef in [('3',.04),('4',4),('20',-2),('24',.1),('25',6),('42',.1),('43',6),('72',-2),('19',2),('26',2),('44',2),('63',6),('80',3),('77',4),('74',5),('86',1)])
    half=std+.5*v('53');ppr=std+v('53')
   result[key]={'season':season,'week':week,'espn_id':str(pid),'player_name':p.get('fullName') or str(pid),'position':pos,'team':TEAMS.get(p.get('proTeamId')),'espn_default_pts':obj.get('appliedTotal'),'pts_std':std,'pts_half_ppr':half,'pts_ppr':ppr,'_has_stats':bool(st),**{name:(float(st[k]) if k in st and st[k] is not None else None) for name,k in STATS.items()}}
 return result

def atomic(path,text):
 path.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.NamedTemporaryFile('w',encoding='utf8',dir=path.parent,delete=False) as f:name=f.name;f.write(text)
 os.replace(name,path)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--start-year',type=int,default=2016);ap.add_argument('--end-year',type=int,default=2025);ap.add_argument('--include-preseason',action='store_true');ap.add_argument('--include-actuals',action='store_true');ap.add_argument('--output-dir',type=Path,default=Path('data_espn'));ap.add_argument('--cache-dir',type=Path,default=Path('cache_espn'));ap.add_argument('--refresh-cache',action='store_true');a=ap.parse_args()
 if a.start_year<2015 or a.end_year<a.start_year:ap.error('Invalid season range')
 session=requests.Session();session.mount('https://',HTTPAdapter(max_retries=Retry(total=4,backoff_factor=1,status_forcelist=[429,500,502,503,504],allowed_methods=['GET'],respect_retry_after_header=True)));session.headers.update({'User-Agent':'Mozilla/5.0','Accept':'application/json','x-fantasy-filter':json.dumps({'players':{'limit':2000,'sortPercOwned':{'sortPriority':1,'sortAsc':False}}})})
 records=[];coverage=[];last=0
 for year in tqdm(range(a.start_year,a.end_year+1),desc='ESPN seasons'):
  path=a.cache_dir/f'espn_season_{year}.json';url=(f'https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/{year}/segments/0/leaguedefaults/3?view=kona_player_info' if year>=2018 else f'https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/leagueHistory/0?seasonId={year}&view=kona_player_info')
  try:
   if path.exists() and not a.refresh_cache:payload=json.loads(path.read_text(encoding='utf8'));rows=normalize(payload,year);status='cached'
   else:
    time.sleep(max(0,.5-(time.monotonic()-last)));r=session.get(url,timeout=(10,60));last=time.monotonic();r.raise_for_status();payload=r.json();rows=normalize(payload,year);atomic(path,json.dumps(payload));status='downloaded'
   records.extend(rows.items());coverage.append({'season':year,'status':status,'records':len(rows),'url':url})
  except (requests.RequestException,ValueError,OSError) as e:coverage.append({'season':year,'status':'failed','detail':str(e),'url':url});print(f'{year}: {e}')
 session.close();a.output_dir.mkdir(parents=True,exist_ok=True)
 actuals={k[:3]:v for k,v in records if k[3]==0};projections=[]
 for key,row in records:
  if key[3]!=1 or not ((row['espn_default_pts'] or 0)>0 or (row['pts_ppr'] or 0)>0):continue
  if a.include_actuals:
   actual=actuals.get(key[:3],{})
   if not actual.get('_has_stats'):actual={}
   for k in ['pts_std','pts_half_ppr','pts_ppr','espn_default_pts']:row['actual_'+k]=actual.get(k)
   row['error_ppr']=(actual['pts_ppr']-row['pts_ppr']) if actual.get('pts_ppr') is not None and row['pts_ppr'] is not None else None
  row.pop('_has_stats',None)
  projections.append(row)
 atomic(a.output_dir/'coverage.json',json.dumps(coverage,indent=2));df=pd.DataFrame(projections)
 if df.empty:return 2
 weekly=df[df.week.ne(0)].sort_values(['season','week','espn_id']);weekly.to_csv(a.output_dir/'espn_weekly_projections.csv',index=False)
 if a.include_preseason:df[df.week.eq(0)].to_csv(a.output_dir/'espn_preseason_projections.csv',index=False)
 print('Rows:',len(weekly));print(weekly.groupby(['season','position']).size().to_string());print(weekly.pts_ppr.agg(['mean','min','max']).to_string());print('2018+ PPR/native correlation:',weekly.loc[weekly.season.ge(2018),['pts_ppr','espn_default_pts']].corr().iloc[0,1]);return 2 if any(x['status']=='failed' for x in coverage) else 0
if __name__=='__main__':raise SystemExit(main())
