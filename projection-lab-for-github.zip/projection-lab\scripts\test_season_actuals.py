import unittest
from add_season_actuals import attach_games, games_played, join_sleeper_projections, join_totals, validate_sleeper


class SeasonActualTests(unittest.TestCase):
    def test_left_join_retains_zero_and_missing(self):
        payload = {'columns': ['season', 'player_id', 'pts_ppr'],
                   'data': [[2025, 'a', 100], [2025, 'b', 100], [2025, 'c', 100]]}
        result = join_totals(payload, {(2025, 'a'): {'pts_ppr': 0},
                                       (2025, 'b'): {'pts_ppr': 125.5}}, 'player_id')
        actual = result['columns'].index('actual_pts_ppr')
        self.assertEqual([row[actual] for row in result['data']], [0, 125.5, None])
        join_totals(payload, {}, 'player_id')
        self.assertEqual(payload['columns'].count('actual_pts_ppr'), 1)

    def test_season_and_id_are_both_join_keys(self):
        p = {'columns': ['season', 'player_id'], 'data': [[2024, '1'], [2025, '1'], [2025, 'BUF']]}
        d = join_totals(p, {(2025, '1'): {'pts_ppr': 21}, (2025, 'BUF'): {'pts_ppr': -5}}, 'player_id')
        self.assertEqual([row[d['columns'].index('actual_pts_ppr')] for row in d['data']], [None, 21, -5])

    def test_rejects_empty_or_malformed_season(self):
        for payload in [{}, [], {'4046': {}}, {'error': 'wrong'}]:
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                validate_sleeper(payload)
        self.assertEqual(validate_sleeper({'4046': {'pts_ppr': 0}})['4046']['pts_ppr'], 0)

    def test_comparison_uses_crosswalk_and_season(self):
        sleeper = {'columns': ['season', 'player_id', 'pts_std', 'pts_half_ppr', 'pts_ppr'],
                   'data': [[2025, 's1', 100, 110, 120]]}
        espn = {'columns': ['season', 'player_id'], 'data': [[2025, 'e1'], [2024, 'e1'], [2025, 'e2']]}
        result = join_sleeper_projections(espn, sleeper, [{'espn_id': 'e1', 'sleeper_id': 's1'}])
        self.assertEqual([row[result['columns'].index('sleeper_pts_ppr')] for row in result['data']], [120, None, None])

    def test_games_excludes_cancelled_game_without_guessing(self):
        weekly = {'allen': {'gp': 1}, 'chase': {'gp': 1}, 'other': {'gp': 1}, 'missing': {'gp': 1}}
        teams = {'allen': {'BUF'}, 'chase': {'CIN'}, 'other': {'KC'}}
        self.assertEqual(games_played({'gp': 17}, 2022, 'allen', weekly, teams), 16)
        self.assertEqual(games_played({'gp': 12}, 2022, 'chase', weekly, teams), 11)
        self.assertEqual(games_played({'gp': 16}, 2022, 'other', weekly, teams), 16)
        self.assertIsNone(games_played({'gp': 16}, 2022, 'missing', weekly, teams))
        self.assertEqual(games_played({'gp': 17}, 2021, 'allen', weekly, teams), 17)
        self.assertEqual(games_played({'gp': 0}, 2025, 'x', weekly, teams), 0)
        self.assertIsNone(games_played({}, 2025, 'x', weekly, teams))
        self.assertIsNone(games_played({'gp': 2.5}, 2025, 'x', weekly, teams))

    def test_games_join_requires_identity_and_year(self):
        p = {'columns': ['season', 'player_id'], 'data': [[2025, 'e1'], [2024, 'e1'], [2025, 'missing']]}
        attach_games(p, {(2025, 's1'): 16}, {'e1': 's1'})
        self.assertEqual([r[p['columns'].index('games_played')] for r in p['data']], [16, None, None])


if __name__ == '__main__':
    unittest.main()
