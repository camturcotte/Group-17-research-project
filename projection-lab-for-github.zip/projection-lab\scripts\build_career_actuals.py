"""Prepare observed regular-season player-week actuals for career profiles.

Uses cached weekly Sleeper statistics and cached ESPN season payloads. Restricts
to player IDs present in the projection archive and the published 2026 snapshot.
An actual week does not require a projection. Missing points are not set to 0.
"""
import argparse
import csv
import json
from pathlib import Path

from fetch_espn_projections import normalize

POINTS = ('pts_std', 'pts_half_ppr', 'pts_ppr')


def extract_rows(path):
    data = json.loads(path.read_text(encoding='utf8'))
    return [dict(zip(data['columns'], row)) for row in data['data']]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dist', type=Path, default=Path('dist'))
    parser.add_argument('--sleeper-archive', type=Path, required=True)
    parser.add_argument('--sleeper-2026', type=Path, required=True)
    parser.add_argument('--espn-cache', type=Path, required=True)
    parser.add_argument('--roster-2022', type=Path, required=True)
    args = parser.parse_args()
    players = {str(r['player_id']) for r in extract_rows(args.dist / 'weekly.json')}
    espn_players = {str(r['player_id']) for r in extract_rows(args.dist / 'espn_weekly.json')}
    crosswalk = json.loads((args.dist / 'player_id_crosswalk.json').read_text(encoding='utf8'))
    espn_to_sleeper = {str(p['espn_id']): str(p['sleeper_id']) for p in crosswalk}
    roster17 = {}
    with args.roster_2022.open(encoding='utf8', newline='') as stream:
        for row in csv.DictReader(stream):
            if row['game_type'] == 'REG' and row['week'] == '17' and row['sleeper_id'] and row['status'] in {'ACT','INA','RES','DEV'}:
                roster17.setdefault(row['sleeper_id'], set()).add(row['team'])

    sleeper, played = [], set()
    for year in range(2018, 2027):
        last = 9 if year == 2026 else (17 if year < 2021 else 18)
        cache = args.sleeper_2026 if year == 2026 else args.sleeper_archive
        for week in range(1, last + 1):
            raw = json.loads((cache / f'actuals_{year}_{week}.json').read_text(encoding='utf8'))
            for pid, stats in raw.items():
                if pid not in players or stats.get('gp') != 1:
                    continue
                if year == 2022 and week == 17:
                    teams = roster17.get(pid, set())
                    if len(teams) != 1 or next(iter(teams)) in {'BUF','CIN'}:
                        continue
                played.add((year,week,pid))
                values = {f'actual_{point}': stats.get(point) for point in POINTS}
                if any(isinstance(v,(int,float)) and not isinstance(v,bool) for v in values.values()):
                    sleeper.append({'player_id':pid,'season':year,'week':week,**values})

    espn = []
    for year in range(2018, 2027):
        raw = json.loads((args.espn_cache / f'espn_season_{year}.json').read_text(encoding='utf8'))
        records = normalize(raw, year)
        # ESPN's 210 means games played. The provider also emits zero-value
        # placeholders for nonparticipants; require a GP flag or a verified
        # Sleeper participation flag before including a weekly actual.
        espn_gp = set()
        wrapped = raw[0] if isinstance(raw, list) else raw
        for entry in wrapped['players']:
            p = entry.get('player',entry); pid = str(p.get('id'))
            if pid not in espn_players: continue
            for stat in p.get('stats',[]):
                week=stat.get('scoringPeriodId')
                if stat.get('seasonId')==year and stat.get('statSourceId')==0 and stat.get('statSplitTypeId')==1 and isinstance(week,int) and 1<=week<=18 and stat.get('stats',{}).get('210',0)>0:
                    espn_gp.add((year,week,pid))
        for (season,week,pid,source), row in records.items():
            if source != 0 or not 1<=week<=(9 if year==2026 else 17 if year<2021 else 18) or pid not in espn_players:
                continue
            sid=espn_to_sleeper.get(pid); verified=(season,week,sid) in played
            if year==2022 and week==17 and sid is not None:
                teams=roster17.get(sid,set())
                if len(teams)!=1 or next(iter(teams)) in {'BUF','CIN'}: continue
            if not verified and (season,week,pid) not in espn_gp: continue
            if row.get('espn_default_pts') is None: continue
            espn.append({'player_id':pid,'season':season,'week':week,**{f'actual_{point}':row.get(point) for point in POINTS}})
    for source, rows in [('sleeper',sleeper),('espn',espn)]:
        keys=[(r['player_id'],r['season'],r['week']) for r in rows]
        if len(keys)!=len(set(keys)): raise ValueError(f'Duplicate {source} player-week actuals')
    (args.dist/'career_actuals.json').write_text(json.dumps({'sleeper':sleeper,'espn':espn},separators=(',',':'),allow_nan=False),encoding='utf8')
    print('Sleeper observed games:',len(sleeper),'ESPN observed games:',len(espn))


if __name__=='__main__':
    main()
