"""Add source-provided full-season actuals to the season projection datasets.

Run from the project directory. Uses all regular-season games, including games
without a weekly projection; missing source totals remain null.
"""
import argparse
import csv
import json
import math
import os
from pathlib import Path
import tempfile
import time

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from fetch_espn_projections import normalize

POINTS = ('pts_std', 'pts_half_ppr', 'pts_ppr')


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile('w', encoding='utf8', dir=path.parent, delete=False) as stream:
            name = stream.name
            json.dump(value, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if name and os.path.exists(name):
            os.unlink(name)


def validate_sleeper(payload):
    if not isinstance(payload, dict) or not payload or not all(isinstance(v, dict) for v in payload.values()):
        raise ValueError('Expected a nonempty map of player IDs to season stats')
    if not any(any(k in stats for k in POINTS) for stats in payload.values()):
        raise ValueError('No fantasy point totals found')
    return payload


def join_totals(payload, totals, id_column):
    """Left-join by season and exact provider ID, preserving zero and null."""
    columns = payload['columns']
    index = {name: columns.index(name) for name in ('season', id_column)}
    for name in POINTS:
        col = 'actual_' + name
        if col not in columns:
            columns.append(col)
            for row in payload['data']:
                row.append(None)
    for row in payload['data']:
        match = totals.get((row[index['season']], str(row[index[id_column]])), {})
        for point in POINTS:
            row[columns.index('actual_' + point)] = match.get(point)
    return payload


def join_sleeper_projections(espn, sleeper, crosswalk):
    """Attach Sleeper season projections to verified ESPN player IDs."""
    sleeper_columns = {k: i for i, k in enumerate(sleeper['columns'])}
    espn_columns = {k: i for i, k in enumerate(espn['columns'])}
    id_map = {str(item['espn_id']): str(item['sleeper_id']) for item in crosswalk}
    projections = {(row[sleeper_columns['season']], str(row[sleeper_columns['player_id']])): row
                   for row in sleeper['data']}
    for point in POINTS:
        col = 'sleeper_' + point
        if col not in espn['columns']:
            espn['columns'].append(col)
            for row in espn['data']:
                row.append(None)
    for row in espn['data']:
        pid = id_map.get(str(row[espn_columns['player_id']]))
        match = projections.get((row[espn_columns['season']], pid))
        for point in POINTS:
            row[espn['columns'].index('sleeper_' + point)] = match[sleeper_columns[point]] if match else None
    return espn


def games_played(stats, year, player_id, week17, teams_by_player):
    """Use actual Sleeper GP, excluding the canceled 2022 BUF-CIN game.

    Sleeper recorded GP for that suspended game even though it was canceled.
    If a player had a week-17 GP flag but cannot be assigned a unique team,
    the official game count is uncertain and is kept missing.
    """
    gp = stats.get('gp')
    if isinstance(gp, bool) or not isinstance(gp, (int, float)) or not math.isfinite(gp) or gp < 0 or gp > 18 or gp != int(gp):
        return None
    if year == 2022 and week17.get(player_id, {}).get('gp') == 1:
        teams = {player_id} if player_id in {'BUF', 'CIN'} else teams_by_player.get(player_id, set())
        if len(teams) != 1:
            return None
        if next(iter(teams)) in {'BUF', 'CIN'}:
            return int(gp) - 1 if gp > 0 else None
    return int(gp)


def attach_games(payload, games_by_id, id_map=None):
    """Join verified player-season counts; never substitute projections."""
    columns = payload['columns']
    season_idx, player_idx = columns.index('season'), columns.index('player_id')
    if 'games_played' not in columns:
        columns.append('games_played')
        for row in payload['data']:
            row.append(None)
    game_idx = columns.index('games_played')
    for row in payload['data']:
        pid = str(row[player_idx])
        if id_map is not None:
            pid = id_map.get(pid)
        row[game_idx] = games_by_id.get((row[season_idx], pid))
    return payload


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dist', type=Path, default=Path('dist'))
    parser.add_argument('--sleeper-cache', type=Path, required=True)
    parser.add_argument('--espn-cache', type=Path, required=True)
    parser.add_argument('--weekly-cache', type=Path, required=True, help='Sleeper raw weekly cache (for canceled 2022 game)')
    parser.add_argument('--roster-2022', type=Path, required=True, help='nflverse weekly roster CSV for 2022')
    args = parser.parse_args()
    sleeper = json.loads((args.dist / 'preseason.json').read_text(encoding='utf8'))
    espn = json.loads((args.dist / 'espn_preseason.json').read_text(encoding='utf8'))
    years = sorted({row[sleeper['columns'].index('season')] for row in sleeper['data']} |
                   {row[espn['columns'].index('season')] for row in espn['data']})
    session = requests.Session()
    session.mount('https://', HTTPAdapter(max_retries=Retry(total=4, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=['GET'], respect_retry_after_header=True)))
    session.headers.update({'User-Agent': 'projection-lab-season-actuals/1.0', 'Accept': 'application/json'})
    sleeper_totals, espn_totals, actual_games, audit = {}, {}, {}, []
    week17 = json.loads((args.weekly_cache / 'actuals_2022_17.json').read_text(encoding='utf8'))
    teams_by_player = {}
    with args.roster_2022.open(encoding='utf8', newline='') as f:
        for row in csv.DictReader(f):
            if row['game_type'] == 'REG' and row['week'] == '17' and row['sleeper_id'] and row['status'] in {'ACT', 'INA', 'RES', 'DEV'}:
                teams_by_player.setdefault(row['sleeper_id'], set()).add(row['team'])
    last = 0.0
    try:
        for year in years:
            cache = args.sleeper_cache / f'actuals_season_{year}.json'
            url = f'https://api.sleeper.app/v1/stats/nfl/regular/{year}'
            if cache.exists():
                body = validate_sleeper(json.loads(cache.read_text(encoding='utf8')))
                origin = 'cached'
            else:
                time.sleep(max(0, .25 - (time.monotonic() - last)))
                response = session.get(url, timeout=(10, 60))
                last = time.monotonic()
                response.raise_for_status()
                body = validate_sleeper(response.json())
                atomic_json(cache, body)
                origin = 'downloaded'
            for pid, stats in body.items():
                sleeper_totals[(year, str(pid))] = {key: stats.get(key) for key in POINTS}
                actual_games[(year, str(pid))] = games_played(stats, year, str(pid), week17, teams_by_player)
            espn_body = json.loads((args.espn_cache / f'espn_season_{year}.json').read_text(encoding='utf8'))
            records = normalize(espn_body, year)
            wrapped = espn_body[0] if isinstance(espn_body, list) else espn_body
            # ESPN emits zero-point placeholders with empty stats for players
            # without a recorded season; these are not evidence of a true zero.
            observed = set()
            for entry in wrapped['players']:
                player = entry.get('player', entry)
                for stat in player.get('stats', []):
                    if (stat.get('seasonId') == year and stat.get('statSourceId') == 0
                            and stat.get('statSplitTypeId') == 0 and stat.get('scoringPeriodId') == 0
                            and stat.get('stats')):
                        observed.add(str(player.get('id')))
            for (season, week, pid, source), record in records.items():
                if week == 0 and source == 0 and pid in observed:
                    espn_totals[(season, pid)] = {key: record.get(key) for key in POINTS}
            audit.append({'season': year, 'sleeper': origin, 'sleeper_url': url, 'espn': 'cached'})
    finally:
        session.close()
    sleeper = join_totals(sleeper, sleeper_totals, 'player_id')
    espn = join_totals(espn, espn_totals, 'player_id')
    crosswalk = json.loads((args.dist / 'player_id_crosswalk.json').read_text(encoding='utf8'))
    espn = join_sleeper_projections(espn, sleeper, crosswalk)
    sleeper = attach_games(sleeper, actual_games)
    espn = attach_games(espn, actual_games, {str(p['espn_id']): str(p['sleeper_id']) for p in crosswalk})
    for label, data in [('Sleeper', sleeper), ('ESPN', espn)]:
        col = data['columns'].index('actual_pts_ppr')
        print(label, 'season records:', len(data['data']), 'matched actual totals:', sum(r[col] is not None for r in data['data']))
    atomic_json(args.dist / 'preseason.json', sleeper)
    atomic_json(args.dist / 'espn_preseason.json', espn)
    atomic_json(args.dist / 'season_actuals_manifest.json', {'method': 'Source-provided full regular-season totals; games played from Sleeper GP for both sources through verified IDs, excluding the canceled 2022 BUF-CIN game. Missing values remain null.', 'seasons': audit})


if __name__ == '__main__':
    main()
