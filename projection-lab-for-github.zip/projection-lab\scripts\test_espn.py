import unittest
from fetch_espn_projections import normalize

def payload(position,stats,points=10):
 return {'players':[{'player':{'id':123,'fullName':'Example','defaultPositionId':position,'proTeamId':2,'stats':[{'seasonId':2025,'statSourceId':1,'statSplitTypeId':1,'scoringPeriodId':1,'stats':stats,'appliedTotal':points}]}}]}

class ESPNTests(unittest.TestCase):
 def test_offense_and_two_point(self):
  d=normalize(payload(2,{'24':100,'25':1,'53':4,'42':20,'72':1,'26':1}),2025)[(2025,1,'123',1)]
  self.assertAlmostEqual(d['pts_std'],18);self.assertAlmostEqual(d['pts_half_ppr'],20);self.assertAlmostEqual(d['pts_ppr'],22)
 def test_kicking_stat_ids(self):
  d=normalize(payload(5,{'80':1,'77':2,'74':1,'81':100,'82':100,'86':2}),2025)[(2025,1,'123',1)]
  self.assertEqual(d['pts_ppr'],18)
 def test_defense_uses_native_expected_points(self):
  d=normalize(payload(16,{'187':17.2,'99':2},7.75),2025)[(2025,1,'123',1)]
  self.assertEqual(d['pts_ppr'],7.75)
 def test_legacy_wrapper_and_identifier(self):
  d=normalize([payload(1,{'3':250,'4':2})],2025)
  self.assertEqual(d[(2025,1,'123',1)]['pts_ppr'],18)
 def test_wrong_season_does_not_overwrite(self):
  data=payload(1,{'3':250});other=data['players'][0]['player']['stats'][0].copy();other['seasonId']=2024;other['appliedTotal']=99;data['players'][0]['player']['stats'].append(other)
  self.assertEqual(normalize(data,2025)[(2025,1,'123',1)]['espn_default_pts'],10)
 def test_conflicting_duplicates_are_not_guessed(self):
  data=payload(1,{'3':250});other=data['players'][0]['player']['stats'][0].copy();other['appliedTotal']=11;data['players'][0]['player']['stats'].append(other)
  self.assertEqual(normalize(data,2025),{})

if __name__=='__main__':unittest.main()
