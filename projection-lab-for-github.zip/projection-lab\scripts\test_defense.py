import unittest
import pandas as pd
from enrich_defense import defense_ranks, unique_lookup


class DefenseTests(unittest.TestCase):
    def setUp(self):
        self.games = pd.DataFrame([
            [2023, 1, 'REG', 'A', 'B', 10, 20],
            [2023, 1, 'REG', 'C', 'D', 10, 20],
            [2023, 2, 'REG', 'A', 'C', 10, 20],
            [2023, 2, 'REG', 'B', 'D', None, None],  # canceled/unplayed
        ], columns=['season', 'week', 'game_type', 'home_team', 'away_team', 'home_score', 'away_score'])
        self.stats = pd.DataFrame([
            [2023, 1, 'A', 'RB', 10, 15, 20],
            [2023, 1, 'B', 'RB', 20, 20, 20],
            [2023, 1, 'C', 'RB', 30, 30, 30],
            [2023, 1, 'D', 'RB', 40, 40, 40],
            [2023, 2, 'A', 'RB', 10000, 10000, 10000],
        ], columns=['season', 'week', 'opponent_team', 'position', 'pts_std', 'pts_half_ppr', 'pts_ppr'])

    def test_excludes_target_week_outlier(self):
        full = defense_ranks(self.stats, self.games)
        changed = self.stats.copy()
        changed.loc[changed.week.eq(2), 'pts_ppr'] = -10000
        other = defense_ranks(changed, self.games)
        pd.testing.assert_frame_equal(full[full.week.eq(2)], other[other.week.eq(2)])
        self.assertEqual(full[(full.week == 2) & (full.defense == 'A') & (full.position == 'RB')].iloc[0].def_allowed_pts_std, 10)

    def test_game_denominator_zero_production_and_cancellation(self):
        out = defense_ranks(self.stats, self.games)
        rb = out[(out.week == 3) & (out.position == 'RB')].set_index('defense')
        self.assertEqual(rb.loc['B', 'def_games'], 1)
        self.assertEqual(rb.loc['C', 'def_games'], 2)
        self.assertEqual(rb.loc['C', 'def_allowed_pts_std'], 15)
        self.assertEqual(rb.loc['A', 'def_allowed_pts_std'], 5005)
        self.assertEqual(rb.loc['A', 'def_rank_pts_std'], 4)

    def test_scoring_ties_and_positions(self):
        out = defense_ranks(self.stats, self.games)
        rb = out[(out.week == 2) & (out.position == 'RB')].set_index('defense')
        self.assertEqual(rb.loc['B', 'def_rank_pts_std'], 2)
        self.assertEqual(rb.loc['A', 'def_rank_pts_ppr'], 1)
        self.assertEqual(rb.loc['B', 'def_rank_pts_ppr'], 1)
        self.assertEqual(rb.loc['C', 'def_rank_pts_ppr'], 3)
        self.assertTrue(out[(out.week == 2) & (out.position == 'QB')].def_rank_pts_ppr.eq(1).all())
        self.assertFalse(out.week.eq(1).any())

    def test_ambiguous_player_mapping_not_guessed(self):
        df = pd.DataFrame({'id': ['a', 'a', 'b', 'b'], 'team': ['A', 'B', 'C', 'C']})
        lookup = unique_lookup(df, ['id'], ['team'])
        self.assertNotIn('a', lookup.index)
        self.assertEqual(lookup.loc['b', 'team'], 'C')


if __name__ == '__main__':
    unittest.main()
