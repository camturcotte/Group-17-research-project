"""Regression checks for the published career player-week actuals snapshot."""
import json
import unittest
from pathlib import Path


class CareerActualTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        dist = Path(__file__).resolve().parents[1] / 'dist'
        cls.actuals = json.loads((dist / 'career_actuals.json').read_text(encoding='utf8'))
        raw = json.loads((dist / 'weekly.json').read_text(encoding='utf8'))
        cls.projected = {(row[raw['columns'].index('season')], row[raw['columns'].index('week')],
                          str(row[raw['columns'].index('player_id')])) for row in raw['data']}

    def test_unique_regular_season_keys_and_2026_cutoff(self):
        for source, records in self.actuals.items():
            keys = [(x['season'], x['week'], x['player_id']) for x in records]
            self.assertEqual(len(keys), len(set(keys)), source)
            self.assertTrue(all(2018 <= x['season'] <= 2026 and 1 <= x['week'] <=
                                (9 if x['season'] == 2026 else 17 if x['season'] < 2021 else 18)
                                for x in records), source)

    def test_actuals_include_games_without_projection(self):
        records = [x for x in self.actuals['sleeper'] if x['player_id'] == '4984' and x['season'] == 2018]
        self.assertTrue(any((r['season'], r['week'], r['player_id']) not in self.projected for r in records))

    def test_cancelled_game_is_excluded(self):
        for source, player_id in [('sleeper', '4984'), ('espn', '3918298')]:
            self.assertFalse(any(x['player_id'] == player_id and x['season'] == 2022 and x['week'] == 17
                                 for x in self.actuals[source]))


if __name__ == '__main__':
    unittest.main()
