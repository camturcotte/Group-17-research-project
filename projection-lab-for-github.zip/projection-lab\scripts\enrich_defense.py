"""Build historical, strictly prior-week defense context for Projection Lab.

Inputs: nflverse weekly rosters, stats_player_week CSVs and schedules/games.csv.
Uses full position-group totals per completed opponent game, including zeros.
Run from project root with --source-dir ../../work/defense-data.
"""
from pathlib import Path
import argparse
import json
from datetime import datetime, timezone
import pandas as pd

POSITIONS = ['QB', 'RB', 'WR', 'TE', 'K']
SCORES = ['pts_std', 'pts_half_ppr', 'pts_ppr']


def team(value):
    return {'LA': 'LAR', 'OAK': 'LV', 'SD': 'LAC', 'STL': 'LAR', 'JAC': 'JAX'}.get(value, value)


def prepare_stats(stats):
    stats = stats[stats.season_type.eq('REG')].copy()
    stats['team'] = stats.team.map(team)
    stats['opponent_team'] = stats.opponent_team.map(team)
    stats['position'] = stats.position.replace({'FB': 'RB', 'HB': 'RB'})
    stats['pts_std'] = stats.fantasy_points
    stats['pts_ppr'] = stats.fantasy_points_ppr
    stats['pts_half_ppr'] = (stats.fantasy_points + stats.fantasy_points_ppr) / 2
    # nflverse's fantasy_points excludes kicking. Use explicit distance scoring.
    # 0–39 yd = 3, 40–49 = 4, 50+ = 5; PAT = 1; misses = -1.
    kick = stats.position.eq('K')
    kicking = (3 * stats[['fg_made_0_19', 'fg_made_20_29', 'fg_made_30_39']].sum(axis=1)
               + 4 * stats.fg_made_40_49
               + 5 * stats[['fg_made_50_59', 'fg_made_60_']].sum(axis=1)
               + stats.pat_made - stats.fg_missed - stats.pat_missed)
    for key in SCORES:
        stats.loc[kick, key] += kicking[kick]
    return stats


def defense_ranks(stats, games):
    """One row per season/week/defense/position, as known through week-1."""
    games = games[games.game_type.eq('REG') & games.home_score.notna() & games.away_score.notna()].copy()
    games['home_team'] = games.home_team.map(team)
    games['away_team'] = games.away_team.map(team)
    schedule = pd.concat([
        games[['season', 'week', 'home_team', 'away_team']].rename(columns={'home_team': 'defense', 'away_team': 'offense'}),
        games[['season', 'week', 'away_team', 'home_team']].rename(columns={'away_team': 'defense', 'home_team': 'offense'}),
    ], ignore_index=True)
    totals = stats[stats.position.isin(POSITIONS)].groupby(
        ['season', 'week', 'opponent_team', 'position'])[SCORES].sum().reset_index().rename(columns={'opponent_team': 'defense'})
    # An actual scheduled game with no production from a position counts as zero.
    scaffold = schedule.merge(pd.DataFrame({'position': POSITIONS}), how='cross')
    game_points = scaffold.merge(totals, on=['season', 'week', 'defense', 'position'], how='left', validate='one_to_one')
    game_points[SCORES] = game_points[SCORES].fillna(0)
    output = []
    for season in sorted(games.season.unique()):
        for week in range(2, 19 if season >= 2021 else 18):
            previous = game_points[(game_points.season == season) & (game_points.week < week)]
            averages = previous.groupby(['defense', 'position'])[SCORES].mean()
            averages['def_games'] = previous.groupby(['defense', 'position']).size()
            averages = averages.reset_index()
            for key in SCORES:
                averages['def_rank_' + key] = averages.groupby('position')[key].rank(method='min', ascending=True).astype(int)
                averages.rename(columns={key: 'def_allowed_' + key}, inplace=True)
            averages['season'], averages['week'] = int(season), week
            output.append(averages)
    return pd.concat(output, ignore_index=True)


def unique_lookup(df, keys, values):
    """Never resolve an ambiguous mapping by guessing or taking the first row."""
    data = df.dropna(subset=keys + values).drop_duplicates(keys + values)
    return data[~data.duplicated(keys, keep=False)].set_index(keys)[values]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--dist', type=Path, default=Path('dist'))
    args = parser.parse_args()
    raw = json.loads((args.dist / 'weekly.json').read_text(encoding='utf-8'))
    data = pd.DataFrame(raw['data'], columns=raw['columns'])
    # Rebuild cleanly if enrichment was already run.
    data = data.drop(columns=[c for c in data if c.startswith('def_') and c != 'def_td'] +
                     [c for c in ['opponent', 'historical_team', 'opponent_status'] if c in data])
    seasons = sorted(data.season.unique())
    stats = prepare_stats(pd.concat([pd.read_csv(args.source_dir / f'stats_player_week_{year}.csv', low_memory=False) for year in seasons], ignore_index=True))
    rosters = pd.concat([pd.read_csv(args.source_dir / f'roster_weekly_{year}.csv', dtype={'sleeper_id': str, 'gsis_id': str}, low_memory=False) for year in seasons], ignore_index=True)
    rosters = rosters[rosters.game_type.eq('REG')].copy()
    rosters['team'] = rosters.team.map(team)
    games = pd.read_csv(args.source_dir / 'games.csv', low_memory=False)
    games = games[games.season.isin(seasons) & games.game_type.eq('REG')].copy()
    games['home_team'], games['away_team'] = games.home_team.map(team), games.away_team.map(team)
    scheduled = pd.concat([
        games[['season', 'week', 'home_team', 'away_team']].rename(columns={'home_team': 'historical_team', 'away_team': 'opponent'}),
        games[['season', 'week', 'away_team', 'home_team']].rename(columns={'away_team': 'historical_team', 'home_team': 'opponent'}),
    ], ignore_index=True)
    # Identity mapping uses stable IDs; weekly team mapping never uses latest_team.
    identity = unique_lookup(rosters, ['sleeper_id'], ['gsis_id'])
    data = data.merge(identity, left_on='player_id', right_index=True, how='left', validate='many_to_one')
    historical = unique_lookup(stats, ['season', 'week', 'player_id'], ['team']).rename(columns={'team': 'historical_team'})
    data = data.merge(historical, left_on=['season', 'week', 'gsis_id'], right_index=True, how='left', validate='many_to_one')
    roster_valid = rosters[rosters.status.isin(['ACT', 'INA', 'RES', 'DEV'])]
    roster_teams = unique_lookup(roster_valid, ['season', 'week', 'sleeper_id'], ['team']).rename(columns={'team': 'roster_team'})
    data = data.merge(roster_teams, left_on=['season', 'week', 'player_id'], right_index=True, how='left', validate='many_to_one')
    data['historical_team'] = data.historical_team.fillna(data.roster_team)
    defenses = data.position.eq('DEF')
    data.loc[defenses, 'historical_team'] = data.loc[defenses, 'player_id'].map(team)
    data = data.merge(scheduled, on=['season', 'week', 'historical_team'], how='left', validate='many_to_one')
    ranks = defense_ranks(stats, games)
    data = data.merge(ranks, left_on=['season', 'week', 'opponent', 'position'],
                      right_on=['season', 'week', 'defense', 'position'], how='left', validate='many_to_one')
    data['opponent_status'] = 'matched'
    data.loc[data.opponent.isna(), 'opponent_status'] = 'historical_team_or_game_unavailable'
    data.loc[data.week.eq(1) & data.opponent.notna(), 'opponent_status'] = 'no_prior_games'
    data.loc[defenses, 'opponent_status'] = 'not_applicable_def'
    # Use historical team for filtering; retain prior metadata separately for audit.
    if 'metadata_team' not in data:
        data['metadata_team'] = data.team
    data['team'] = data.historical_team
    data = data.drop(columns=['gsis_id', 'roster_team', 'defense'])
    assert len(data) == len(raw['data'])
    assert not data.duplicated(['season', 'week', 'player_id']).any()
    assert data.loc[data.week.eq(1), 'def_rank_pts_ppr'].isna().all()
    assert data.loc[data.position.eq('DEF'), 'def_rank_pts_ppr'].isna().all()
    assert data.def_rank_pts_ppr.dropna().between(1, 32).all()
    (args.dist / 'weekly.json').write_text(data.to_json(orient='split', index=False), encoding='utf-8')
    ranks.to_csv(args.dist / 'defense_rankings.csv', index=False)
    report = {'built_at': datetime.now(timezone.utc).isoformat(), 'weekly_rows': len(data),
              'opponent_matched': int(data.opponent.notna().sum()),
              'ranked_rows': int(data.def_rank_pts_ppr.notna().sum()),
              'week_1_rows': int(data.week.eq(1).sum()), 'defense_rows': int(defenses.sum()),
              'unmatched_rows': int(data.opponent.isna().sum()),
              'method': 'Prior regular-season weeks only; mean total fantasy points allowed to a position per completed defensive game; rank 1 = fewest allowed; ties use minimum rank.',
              'sources': ['https://github.com/nflverse/nflverse-data/releases/tag/stats_player',
                          'https://github.com/nflverse/nflverse-data/releases/tag/weekly_rosters',
                          'https://github.com/nflverse/nflverse-data/releases/tag/schedules'],
              'kicker_scoring': 'FG 0-39=3, 40-49=4, 50+=5; PAT=1; missed FG/PAT=-1; plus any offensive fantasy points.',
              'limitations': 'Latest corrected historical box scores, not archived as-of data revisions. Unresolved historical teams are not replaced by current metadata. DEF rows have no defense-vs-position rank.'}
    (args.dist / 'defense_context_manifest.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
    print(data[(data.player_name.str.contains('Achane')) & data.season.eq(2023) & data.week.eq(3)][['player_name','team','opponent','def_rank_pts_ppr','def_allowed_pts_ppr','def_games']].to_string(index=False))


if __name__ == '__main__':
    main()
